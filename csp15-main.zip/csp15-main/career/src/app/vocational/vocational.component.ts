import { Component } from '@angular/core';

@Component({
  selector: 'app-vocational',
  templateUrl: './vocational.component.html',
  styleUrls: ['./vocational.component.css']
})
export class VocationalComponent {

}
