import { Component } from '@angular/core';

@Component({
  selector: 'app-poly',
  templateUrl: './poly.component.html',
  styleUrls: ['./poly.component.css']
})
export class PolyComponent {

}
