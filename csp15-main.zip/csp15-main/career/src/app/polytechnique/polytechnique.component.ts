import { Component } from '@angular/core';

@Component({
  selector: 'app-polytechnique',
  templateUrl: './polytechnique.component.html',
  styleUrls: ['./polytechnique.component.css']
})
export class PolytechniqueComponent {

}
