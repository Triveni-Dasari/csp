import { Component } from '@angular/core';

@Component({
  selector: 'app-iti',
  templateUrl: './iti.component.html',
  styleUrls: ['./iti.component.css']
})
export class ItiComponent {

}
