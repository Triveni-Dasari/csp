import { Component } from '@angular/core';

@Component({
  selector: 'app-contactread',
  templateUrl: './contactread.component.html',
  styleUrls: ['./contactread.component.css']
})
export class ContactreadComponent {

}
